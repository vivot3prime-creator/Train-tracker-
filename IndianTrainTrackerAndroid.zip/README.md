# Indian Train Tracker — Android

Native Android starter app built with Kotlin and Jetpack Compose.

## Features
- Search by train number or train name using RailRadar API
- Live running status, delay, last reported station, next halt
- Daily timetable with station arrival/departure, day, distance and platform
- Helpful error states for invalid train, missing API key, network failures, API quota and service errors
- Responsive Material 3 mobile UI

## Requirements
- Android Studio (current stable) and Android SDK
- JDK 17
- API key from RailRadar. The app does not bundle a shared key.

## Build APK
1. Extract the ZIP.
2. Open the `IndianTrainTrackerAndroid` folder in Android Studio.
3. Let Gradle sync and install any suggested SDK components.
4. Run on a connected Android phone or emulator.
5. To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When build succeeds, use **Locate** to find the debug APK.

This is source code, not a compiled APK. It has not been built or tested against a live API key in this environment.

## API docs
- Train schedule: https://railradar.in/docs/get-train-details
- Live status: https://railradar.in/docs/live-train-status
- Train search: https://railradar.in/docs/search-trains

The app uses `Authorization: Bearer YOUR_API_KEY` for `https://api.railradar.in/v1`.
API limits and access depend on the provider plan. Avoid sharing your API key.

## Limitations
- Live status can be unavailable for some trains or when upstream telemetry is delayed.
- Always verify critical travel details with official railway sources.
- This is an independent app, not an official Indian Railways app.
