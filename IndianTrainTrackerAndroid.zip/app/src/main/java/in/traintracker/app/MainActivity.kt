package in.traintracker.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.DirectionsRailway
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private val Navy = Color(0xFF12233F)
private val Blue = Color(0xFF2563EB)
private val Background = Color(0xFFF4F7FB)
private val Ink = Color(0xFF182230)
private val Muted = Color(0xFF66758A)
private val Green = Color(0xFF16803D)
private val Amber = Color(0xFFB45309)
private val Card = Color.White

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TrainTrackerTheme { TrainTrackerScreen() } }
    }
}

@Composable
private fun TrainTrackerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, onPrimary = Color.White, background = Background,
            surface = Card, onSurface = Ink, secondary = Green
        ),
        content = content
    )
}

data class TrainHit(val number: String, val name: String, val source: String, val destination: String)
data class StopRow(
    val sequence: String, val station: String, val code: String,
    val arrival: String, val departure: String, val day: String,
    val distance: String, val status: String, val delay: String, val platform: String
)
data class TrainResult(
    val number: String, val name: String, val source: String, val destination: String,
    val status: String, val delay: String, val current: String, val next: String,
    val updated: String, val distance: String, val stops: List<StopRow>
)

@Composable
private fun TrainTrackerScreen() {
    var query by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Enter a train number or name to get started.") }
    var error by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf(emptyList<TrainHit>()) }
    var result by remember { mutableStateOf<TrainResult?>(null) }
    var tab by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    fun search() {
        val q = query.trim()
        if (q.length < 2) {
            message = "Enter a train number or at least 2 letters of a train name."
            error = true
            return
        }
        if (apiKey.isBlank()) {
            message = "Add your RailRadar API key in Settings before searching."
            error = true
            showSettings = true
            return
        }
        isLoading = true
        error = false
        message = "Searching trains…"
        result = null
        matches = emptyList()
        scope.launch {
            try {
                if (q.matches(Regex("\\d{4,6}"))) {
                    result = withContext(Dispatchers.IO) { fetchTrain(q, apiKey) }
                    message = "Train data loaded. Confirm important travel details with official railway updates."
                } else {
                    matches = withContext(Dispatchers.IO) { searchTrains(q, apiKey) }
                    message = if (matches.isEmpty()) "No matching train found. Try another name or train number." else "Choose the matching train below."
                }
            } catch (e: Exception) {
                message = friendlyError(e.message ?: "Unknown error")
                error = true
            } finally {
                isLoading = false
            }
        }
    }

    fun selectTrain(hit: TrainHit) {
        query = hit.number
        isLoading = true
        error = false
        message = "Loading ${hit.name}…"
        matches = emptyList()
        scope.launch {
            try {
                result = withContext(Dispatchers.IO) { fetchTrain(hit.number, apiKey) }
                message = "Train data loaded. Last updated: ${result?.updated ?: "not supplied"}"
            } catch (e: Exception) {
                message = friendlyError(e.message ?: "Unknown error")
                error = true
            } finally {
                isLoading = false
            }
        }
    }

    Scaffold(
        containerColor = Background,
        topBar = {
            Row(
                modifier = Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(46.dp).background(Color(0xFFDAE7FF), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.DirectionsRailway, contentDescription = null, tint = Navy, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Indian Train Tracker", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Live running status & daily timetable", color = Color(0xFFD3DDED), fontSize = 12.sp)
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "API settings", tint = Color.White)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Find your train", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Search by train number or train name.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))
                        OutlinedTextField(
                            value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("e.g. 12919 or Malwa Express") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { search() }, enabled = !isLoading, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                                Spacer(Modifier.width(10.dp))
                            } else {
                                Icon(Icons.Default.Search, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                            }
                            Text(if (isLoading) "Please wait…" else "Search train", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = if (error) Color(0xFFFFF4E5) else Color(0xFFEAF2FF))) {
                    Text(message, modifier = Modifier.fillMaxWidth().padding(14.dp), color = if (error) Amber else Color(0xFF234A86), fontSize = 13.sp)
                }
            }
            if (matches.isNotEmpty()) {
                item { Text("Matching trains", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                items(matches) { hit ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selectTrain(hit) },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Card)
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${hit.number} · ${hit.name}", color = Navy, fontWeight = FontWeight.Bold)
                                Text("${hit.source}  →  ${hit.destination}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                            }
                            Icon(Icons.Default.ArrowForward, contentDescription = "Select train", tint = Blue)
                        }
                    }
                }
            }
            result?.let { train ->
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Navy)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("${train.number} · ${train.name}", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text("${train.source}  →  ${train.destination}", color = Color(0xFFD3DDED), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                            Spacer(Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetricCard("STATUS", train.status.replace('_', ' ').uppercase(), Modifier.weight(1f), Color.White)
                                MetricCard("DELAY", train.delay, Modifier.weight(1f), if (train.delay.startsWith("0") || train.delay == "On time") Color(0xFFB7F7C8) else Color(0xFFFFD08A))
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetricCard("LAST REPORTED", train.current, Modifier.weight(1f), Color.White)
                                MetricCard("NEXT HALT", train.next, Modifier.weight(1f), Color.White)
                            }
                            Text("Last update: ${train.updated}", color = Color(0xFFB8C7DB), fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp))
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Live route") })
                        FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Daily schedule") })
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { query = train.number; search() }, enabled = !isLoading) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    }
                }
                if (train.stops.isEmpty()) {
                    item { Text("No station list was included in the API response.", color = Muted, modifier = Modifier.padding(8.dp)) }
                } else {
                    items(train.stops) { stop ->
                        StopCard(stop, live = tab == 0)
                    }
                }
            }
            item {
                Text(
                    "Data provided by RailRadar API. This is an independent app, not an official Indian Railways service.",
                    color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("RailRadar API settings") },
            text = {
                Column {
                    Text("Paste your own API key from the provider's official dashboard. The key is kept only in this screen's memory and is not saved to disk.", fontSize = 13.sp, color = Muted)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = apiKey, onValueChange = { apiKey = it },
                        label = { Text("API key") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    TextButton(onClick = { showSettings = false }) { Text("Done") }
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier, valueColor: Color) {
    Column(modifier.background(Color(0x1FFFFFFF), RoundedCornerShape(12.dp)).padding(10.dp)) {
        Text(label, color = Color(0xFFCAD5E5), fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        Text(value.ifBlank { "—" }, color = valueColor, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, lineHeight = 17.sp, modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable
private fun StopCard(stop: StopRow, live: Boolean) {
    Card(shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.Top) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(34.dp)) {
                Box(Modifier.size(30.dp).background(Color(0xFFE6EEFF), CircleShape), contentAlignment = Alignment.Center) {
                    Text(stop.sequence, color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width(2.dp).height(36.dp).background(Color(0xFFD8E1EE)))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(stop.station, color = Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(stop.code, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("Arrival", color = Muted, fontSize = 10.sp)
                        Text(stop.arrival, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Departure", color = Muted, fontSize = 10.sp)
                        Text(stop.departure, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                    Column(Modifier.weight(0.7f)) {
                        Text(if (live) "Delay" else "Day", color = Muted, fontSize = 10.sp)
                        Text(if (live) stop.delay else stop.day, color = if (live && stop.delay != "—" && stop.delay != "0 min") Amber else Ink, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    buildString {
                        append("Distance: ${stop.distance} km")
                        if (stop.platform != "—") append("  ·  Platform ${stop.platform}")
                        if (live && stop.status != "—") append("  ·  ${stop.status}")
                    },
                    color = Muted, fontSize = 11.sp
                )
            }
        }
    }
}

private fun apiGet(path: String, apiKey: String): JSONObject {
    val connection = (URL("https://api.railradar.in/v1$path").openConnection() as HttpURLConnection)
    connection.requestMethod = "GET"
    connection.connectTimeout = 15000
    connection.readTimeout = 20000
    connection.setRequestProperty("Authorization", "Bearer $apiKey")
    connection.setRequestProperty("Accept", "application/json")
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        if (code !in 200..299 || !json.optBoolean("success", true)) {
            val apiMessage = json.optJSONObject("error")?.optString("message").orEmpty()
            val msg = when (code) {
                401 -> "API key गलत या expire है। Settings में key जाँचें।"
                403 -> "API plan में इस endpoint की अनुमति नहीं है।"
                404 -> "ट्रेन नहीं मिली। नंबर या नाम जाँचें।"
                429 -> "API request limit पूरी हो गई है। बाद में कोशिश करें।"
                in 500..599 -> "RailRadar service अभी उपलब्ध नहीं है। कुछ देर बाद कोशिश करें।"
                else -> apiMessage.ifBlank { "API request failed (HTTP $code)." }
            }
            throw IllegalStateException(msg)
        }
        return json.optJSONObject("data") ?: JSONObject()
    } finally {
        connection.disconnect()
    }
}

private fun searchTrains(query: String, apiKey: String): List<TrainHit> =
    searchTrainsArray(query, apiKey)

private fun searchTrainsArray(query: String, apiKey: String): List<TrainHit> {
    val encoded = URLEncoder.encode(query, "UTF-8")
    val connection = (URL("https://api.railradar.in/v1/lookup/search/trains?q=$encoded&limit=10").openConnection() as HttpURLConnection)
    connection.requestMethod = "GET"
    connection.connectTimeout = 15000
    connection.readTimeout = 20000
    connection.setRequestProperty("Authorization", "Bearer $apiKey")
    connection.setRequestProperty("Accept", "application/json")
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        val root = JSONObject(body)
        if (code !in 200..299 || !root.optBoolean("success", true)) {
            val apiMessage = root.optJSONObject("error")?.optString("message").orEmpty()
            throw IllegalStateException(if (code == 401) "API key गलत या expire है। Settings में key जाँचें।" else apiMessage.ifBlank { "Train search failed (HTTP $code)." })
        }
        val array = root.optJSONArray("data") ?: JSONArray()
        val list = mutableListOf<TrainHit>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            list += TrainHit(
                number = item.optString("number", item.optString("trainNumber", item.optString("train_number", ""))),
                name = item.optString("name", item.optString("trainName", item.optString("train_name", "Train"))),
                source = item.optString("sourceName", item.optString("source_station_name", item.optString("source", "—"))),
                destination = item.optString("destinationName", item.optString("destination_station_name", item.optString("destination", "—")))
            )
        }
        return list.filter { it.number.isNotBlank() }
    } finally {
        connection.disconnect()
    }
}

private fun fetchTrain(number: String, apiKey: String): TrainResult {
    val encoded = URLEncoder.encode(number, "UTF-8")
    val schedule = apiGet("/trains/$encoded", apiKey)
    val live = try { apiGet("/trains/$encoded/live", apiKey) } catch (_: Exception) { JSONObject() }
    val train = schedule.optJSONObject("train") ?: live.optJSONObject("train") ?: JSONObject()
    val liveTrain = live.optJSONObject("train") ?: JSONObject()
    val sourceObj = train.optJSONObject("source") ?: JSONObject()
    val destObj = train.optJSONObject("destination") ?: JSONObject()
    val location = live.optJSONObject("currentLocation") ?: JSONObject()
    val previous = live.optJSONObject("previousHalt") ?: JSONObject()
    val next = live.optJSONObject("nextHalt") ?: JSONObject()
    val source = sourceObj.optString("name", sourceObj.optString("code", "—"))
    val destination = destObj.optString("name", destObj.optString("code", "—"))
    val liveRoute = live.optJSONArray("route")
    val scheduleRoute = schedule.optJSONArray("route")
    val useLive = liveRoute != null && liveRoute.length() > 0
    val route = if (useLive) liveRoute!! else scheduleRoute ?: JSONArray()
    val stops = mutableListOf<StopRow>()
    for (i in 0 until route.length()) {
        val item = route.optJSONObject(i) ?: continue
        val station = item.optJSONObject("station") ?: JSONObject()
        val stationName = item.optString("stationName", station.optString("name", "Unknown station"))
        val stationCode = item.optString("stationCode", station.optString("code", "—"))
        val delayValue = item.opt("delayArrival").takeIf { it != null && it != JSONObject.NULL }
            ?: item.opt("delayDeparture").takeIf { it != null && it != JSONObject.NULL }
        stops += StopRow(
            sequence = item.optString("sequence", (i + 1).toString()),
            station = stationName,
            code = stationCode,
            arrival = formatTime(item.optString(if (useLive) "scheduledArrival" else "arrival", "")),
            departure = formatTime(item.optString(if (useLive) "scheduledDeparture" else "departure", "")),
            day = item.optString("arrivalDay", item.optString("departureDay", "—")),
            distance = item.optString("distance", "—"),
            status = item.optString("status", "—"),
            delay = if (delayValue == null || delayValue == JSONObject.NULL) "—" else "$delayValue min",
            platform = item.optString("platform", "—")
        )
    }
    val delay = live.opt("delayMinutes")
    val delayText = when {
        delay == null || delay == JSONObject.NULL -> "—"
        delay.toString() == "0" -> "On time"
        else -> "$delay min"
    }
    val current = firstNonBlank(location.optString("stationName"), previous.optString("stationName"),
        location.optString("stationCode"), previous.optString("stationCode"))
    val nextStation = firstNonBlank(next.optString("stationName"), next.optString("stationCode"))
    return TrainResult(
        number = firstNonBlank(live.optString("trainNumber"), train.optString("number"), number),
        name = firstNonBlank(live.optString("trainName"), liveTrain.optString("name"), train.optString("name"), "Train $number"),
        source = source, destination = destination,
        status = live.optString("status", "Live unavailable"),
        delay = delayText, current = current, next = nextStation,
        updated = live.optString("lastUpdatedAt", "—"),
        distance = train.optString("distance", "—"),
        stops = stops
    )
}

private fun formatTime(value: String): String {
    if (value.isBlank() || value == "null") return "—"
    return if (value.contains("T") && value.length >= 16) value.substring(11, 16) else value
}

private fun firstNonBlank(vararg values: String): String =
    values.firstOrNull { it.isNotBlank() && it != "null" && it != "—" } ?: "—"

private fun friendlyError(raw: String): String = when {
    raw.contains("Unable to resolve host", true) || raw.contains("failed to connect", true) ->
        "Internet connection नहीं मिला। इंटरनेट जाँचकर फिर कोशिश करें।"
    raw.contains("timeout", true) -> "Server ने समय पर जवाब नहीं दिया। फिर कोशिश करें।"
    else -> raw
}
